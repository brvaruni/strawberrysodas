import 'package:parking_lot_booking_system/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:parking_lot_booking_system/core/app_export.dart';

class FourScreen extends StatelessWidget {
  FourScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController editTextController = TextEditingController();

  TextEditingController editTextController1 = TextEditingController();

  TextEditingController editTextController2 = TextEditingController();

  TextEditingController editTextController3 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 46.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 12.v),
              Padding(
                padding: EdgeInsets.only(left: 6.h),
                child: Text(
                  "Plate Number:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              _buildEditText(context),
              SizedBox(height: 44.v),
              Padding(
                padding: EdgeInsets.only(left: 10.h),
                child: Text(
                  "Slot:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              _buildEditText1(context),
              SizedBox(height: 40.v),
              Padding(
                padding: EdgeInsets.only(left: 7.h),
                child: Text(
                  "Entry Time:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              _buildEditText2(context),
              SizedBox(height: 48.v),
              Padding(
                padding: EdgeInsets.only(left: 6.h),
                child: Text(
                  "Exit time:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              _buildEditText3(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEditText(BuildContext context) {
    return Opacity(
      opacity: 0.7,
      child: Padding(
        padding: EdgeInsets.only(left: 3.h),
        child: CustomTextFormField(
          controller: editTextController,
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEditText1(BuildContext context) {
    return Opacity(
      opacity: 0.7,
      child: Padding(
        padding: EdgeInsets.only(left: 3.h),
        child: CustomTextFormField(
          controller: editTextController1,
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEditText2(BuildContext context) {
    return Opacity(
      opacity: 0.7,
      child: Padding(
        padding: EdgeInsets.only(left: 3.h),
        child: CustomTextFormField(
          controller: editTextController2,
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEditText3(BuildContext context) {
    return Opacity(
      opacity: 0.7,
      child: Padding(
        padding: EdgeInsets.only(left: 3.h),
        child: CustomTextFormField(
          controller: editTextController3,
          textInputAction: TextInputAction.done,
        ),
      ),
    );
  }
}
