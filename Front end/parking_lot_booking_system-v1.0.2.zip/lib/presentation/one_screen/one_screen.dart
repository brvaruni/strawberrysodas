import 'package:flutter/material.dart';
import 'package:parking_lot_booking_system/core/app_export.dart';

class OneScreen extends StatelessWidget {
  const OneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 9.h,
            top: 230.v,
            right: 9.h,
          ),
          child: Column(
            children: [
              SizedBox(height: 5.v),
              _buildEAZYPARK(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEAZYPARK(BuildContext context) {
    return SizedBox(
      height: 276.v,
      width: 371.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(bottom: 29.v),
              child: Text(
                "EAZY PARK",
                style: CustomTextStyles.displayMedium50,
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: SizedBox(
              height: 276.v,
              width: 371.h,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgScreenshot20240323,
                    height: 276.v,
                    alignment: Alignment.center,
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 27.v),
                      child: SizedBox(
                        width: 126.h,
                        child: Divider(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
