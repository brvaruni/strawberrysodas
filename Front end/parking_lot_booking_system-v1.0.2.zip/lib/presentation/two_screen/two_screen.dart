import 'package:parking_lot_booking_system/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:parking_lot_booking_system/core/app_export.dart';

class TwoScreen extends StatelessWidget {
  TwoScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController firstNameController = TextEditingController();

  TextEditingController editTextController = TextEditingController();

  TextEditingController editTextController1 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 48.h,
            top: 134.v,
            right: 48.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 77.h),
                child: Text(
                  "LOGIN",
                  style: theme.textTheme.displayMedium,
                ),
              ),
              SizedBox(height: 38.v),
              Padding(
                padding: EdgeInsets.only(left: 1.h),
                child: Text(
                  "First Name:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 5.v),
              Opacity(
                opacity: 0.7,
                child: Padding(
                  padding: EdgeInsets.only(left: 1.h),
                  child: CustomTextFormField(
                    controller: firstNameController,
                  ),
                ),
              ),
              SizedBox(height: 44.v),
              Padding(
                padding: EdgeInsets.only(left: 8.h),
                child: Text(
                  "Last Name:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              Opacity(
                opacity: 0.7,
                child: Padding(
                  padding: EdgeInsets.only(left: 1.h),
                  child: CustomTextFormField(
                    controller: editTextController,
                  ),
                ),
              ),
              SizedBox(height: 38.v),
              Padding(
                padding: EdgeInsets.only(left: 5.h),
                child: Text(
                  "Phone Number:",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 5.v),
              Opacity(
                opacity: 0.7,
                child: Padding(
                  padding: EdgeInsets.only(left: 1.h),
                  child: CustomTextFormField(
                    controller: editTextController1,
                    textInputAction: TextInputAction.done,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
