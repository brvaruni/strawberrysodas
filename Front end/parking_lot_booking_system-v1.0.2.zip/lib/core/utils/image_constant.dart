class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // One images
  static String imgScreenshot20240323 =
      '$imagePath/img_screenshot_2024_03_23.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
