package com.parkinglotbookingsystem.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
